import geopandas as gpd
from shapely.ops import unary_union
import os

def preprocess_shadow_data(input_dir, output_dir, delete_original=False):
    """
    指定されたディレクトリ内のcombined_shadow_*.geojsonファイルを読み込み、
    unary_unionで統合したmerged_shadow_*.geojsonファイルを出力します。
    delete_originalがTrueの場合、統合後に元のファイルを削除します。
    """
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    geojson_files = [f for f in os.listdir(input_dir) if f.startswith('combined_shadow_') and f.endswith('.geojson')]
    
    if not geojson_files:
        print("統合するファイルが見つかりませんでした。")
        return

    for filename in geojson_files:
        input_filepath = os.path.join(input_dir, filename)
        output_filename = filename.replace('combined_shadow_', 'merged_shadow_')
        output_filepath = os.path.join(output_dir, output_filename)

        if os.path.exists(output_filepath):
            print(f"統合済みファイル {output_filename} は既に存在します。スキップします。")
            if delete_original:
                try:
                    os.remove(input_filepath)
                    print(f"元のファイル {filename} を削除しました。")
                except OSError as e:
                    print(f"元のファイル {filename} の削除中にエラーが発生しました: {e}")
            continue

        print(f"--- {filename} を統合中... ---")
        try:
            # 複数のGeoJSONフィーチャーを読み込む
            gdf = gpd.read_file(input_filepath)
            
            # ジオメトリをunary_unionで統合
            merged_geometry = unary_union(gdf.geometry)
            
            # 統合されたジオメトリで新しいGeoDataFrameを作成
            merged_gdf = gpd.GeoDataFrame(geometry=[merged_geometry], crs=gdf.crs)
            
            # ファイルに出力
            merged_gdf.to_file(output_filepath, driver='GeoJSON')
            print(f"統合済みファイルを {output_filepath} に出力しました。")

            # 統合が成功した場合にのみ、元のファイルを削除
            if delete_original:
                os.remove(input_filepath)
                print(f"元のファイル {filename} を削除しました。")

        except Exception as e:
            print(f"ファイル {filename} の処理中にエラーが発生しました: {e}")

if __name__ == "__main__":
    input_directory = 'shadow_rt/static'
    output_directory = 'shadow_rt/static'
    
    # 統合後に元のファイルを削除するには、delete_original=Trueを設定
    preprocess_shadow_data(input_directory, output_directory, delete_original=True)