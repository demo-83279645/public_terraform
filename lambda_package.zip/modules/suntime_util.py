# suntime_util.py
from astral import LocationInfo
from astral.sun import sun
import datetime
from dateutil import tz
import math

def get_rounded_sun_times(date: datetime.date):
    """
    指定された日の日の出と日没時刻を取得し、
    分が30分より大きい場合は1時間繰り上げ、
    30分以下の場合は分を切り捨てて時刻を返す。
    日の出は前日、日没は当日でUTC時刻を取得する。

    Args:
        date (datetime.date): 処理対象の日付。

    Returns:
        tuple[datetime.datetime, datetime.datetime]: 
            日の出と日没の丸められた日本時間。
    """
    city = LocationInfo("Fukuoka", "Japan", "Asia/Tokyo", 33.5913, 130.4017)
    japan_tz = tz.gettz("Asia/Tokyo")

    # 日の出は前日の日付でUTC時刻を取得
    yesterday = date - datetime.timedelta(days=1)
    s_sunrise = sun(city.observer, date=yesterday)
    sunrise_utc = s_sunrise['sunrise']
    
    # 日没は当日の日付でUTC時刻を取得
    s_sunset = sun(city.observer, date=date)
    sunset_utc = s_sunset['sunset']
    
    # 日本時間へ変換
    sunrise_local = sunrise_utc.astimezone(japan_tz)
    sunset_local = sunset_utc.astimezone(japan_tz)
    
    """
     # --- デバッグ出力の追加 ---
    print(f"DEBUG: 元の日付: {date}")
    print(f"DEBUG: 日の出計算用日付: {yesterday}")
    print(f"DEBUG: UTC 日の出時刻: {sunrise_utc}")
    print(f"DEBUG: 日没計算用日付: {date}")
    print(f"DEBUG: UTC 日没時刻: {sunset_utc}")
    print(f"DEBUG: 日本時間 日の出時刻: {sunrise_local}")
    print(f"DEBUG: 日本時間 日没時刻: {sunset_local}")
    # ---------------------------
    """

    # 分の丸め処理
    def round_time_to_hour(dt):
        original_dt = dt # 元の時刻を保持
        if dt.minute > 30:
            # 1時間繰り上げ
            rounded_dt = dt.replace(minute=0, second=0, microsecond=0) + datetime.timedelta(hours=1)
        else:
            # 分を切り捨て
            rounded_dt = dt.replace(minute=0, second=0, microsecond=0)
        
        # --- 個別のデバッグ出力 ---
        # print(f"DEBUG: 丸め処理: {original_dt} -> {rounded_dt}")
        # ---------------------------
        return rounded_dt

    rounded_sunrise = round_time_to_hour(sunrise_local)
    rounded_sunset = round_time_to_hour(sunset_local)
    
    return rounded_sunrise, rounded_sunset

if __name__ == '__main__':
    # テスト用
    today = datetime.date.today()
    sunrise, sunset = get_rounded_sun_times(today)
""" 
    print(f"\n最終結果:")
    print(f"丸められた日の出時刻: {sunrise.strftime('%Y-%m-%d %H:%M:%S%z')}")
    print(f"丸められた日没時刻: {sunset.strftime('%Y-%m-%d %H:%M:%S%z')}")
     """