# shadow_combiner.py
import geopandas as gpd
from shapely.geometry import Polygon, MultiPolygon, Point, MultiPoint
from shapely.ops import unary_union
import json
import os

def combine_shadow_and_footprint_geometries(footprint_geojson_path, shadow_geojson_path, output_geojson_path):
    """
    建物のフットプリントGeoJSONと伸びる影GeoJSONを読み込み、
    それらを結合して一つの完全な日影GeoJSONファイルを生成します。
    """
    try:
        # 1. GeoJSONファイルの読み込み
        if not os.path.exists(footprint_geojson_path) or not os.path.exists(shadow_geojson_path):
            print(f"エラー: 入力ファイルが見つかりません。フットプリント: {os.path.exists(footprint_geojson_path)}, 影: {os.path.exists(shadow_geojson_path)}")
            # 空のGeoJSONファイルを生成して終了
            empty_gdf = gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")
            empty_gdf.to_file(output_geojson_path, driver='GeoJSON')
            return

        footprint_gdf = gpd.read_file(footprint_geojson_path)
        shadow_gdf = gpd.read_file(shadow_geojson_path)

        if footprint_gdf.empty and shadow_gdf.empty:
            print("警告: 両方の入力GeoJSONファイルにジオメトリが見つかりませんでした。")
            empty_gdf = gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")
            empty_gdf.to_file(output_geojson_path, driver='GeoJSON')
            return

        # 建物IDをキーとしてジオメトリを辞書に格納するヘルパー関数
        def get_geometries_by_id(gdf):
            geoms_by_id = {}
            for idx, row in gdf.iterrows():
                feature_id = row.get('id', str(idx))
                
                geoms_to_add = []
                geom = row['geometry']
                if geom is not None and not geom.is_empty:
                    if isinstance(geom, MultiPolygon):
                        geoms_to_add.extend([g for g in geom.geoms if g and not g.is_empty and g.is_valid])
                    elif isinstance(geom, Polygon):
                        if geom.is_valid and not geom.is_empty:
                            geoms_to_add.append(geom)
                
                if feature_id is not None and geoms_to_add:
                    if feature_id not in geoms_by_id:
                        geoms_by_id[feature_id] = []
                    geoms_by_id[feature_id].extend(geoms_to_add)
            return geoms_by_id

        footprint_geoms_by_id = get_geometries_by_id(footprint_gdf)
        shadow_geoms_by_id = get_geometries_by_id(shadow_gdf)

        all_combined_geometries = []
        all_building_ids = set(footprint_geoms_by_id.keys()).union(shadow_geoms_by_id.keys())

        for building_id in all_building_ids:
            current_building_geometries = []

            if building_id in footprint_geoms_by_id:
                for geom in footprint_geoms_by_id[building_id]:
                    if geom and not geom.is_empty and geom.is_valid:
                        current_building_geometries.append(geom)

            if building_id in shadow_geoms_by_id:
                for geom in shadow_geoms_by_id[building_id]:
                    if geom and not geom.is_empty and geom.is_valid:
                        current_building_geometries.append(geom)

            if not current_building_geometries:
                continue

            # 2. すべてのジオメトリをunary_unionで結合
            combined_geometry = unary_union(current_building_geometries)
            
            final_geometry = None
            if isinstance(combined_geometry, (MultiPolygon, Polygon)):
                points = []
                if isinstance(combined_geometry, Polygon):
                    points.extend(list(combined_geometry.exterior.coords))
                elif isinstance(combined_geometry, MultiPolygon):
                    for poly in combined_geometry.geoms:
                        if isinstance(poly, Polygon) and not poly.is_empty and poly.is_valid:
                            points.extend(list(poly.exterior.coords))
                
                if points:
                    multi_point = MultiPoint(points)
                    final_geometry = multi_point.convex_hull
                    if not final_geometry.is_valid or final_geometry.is_empty:
                         final_geometry = combined_geometry
                else:
                    final_geometry = combined_geometry
            else:
                valid_parts = [g for g in combined_geometry.geoms if isinstance(g, (Polygon, MultiPolygon)) and not g.is_empty and g.is_valid]
                if valid_parts:
                    final_geometry = unary_union(valid_parts)
                else:
                    final_geometry = Polygon()

            if final_geometry and not final_geometry.is_empty and final_geometry.is_valid:
                all_combined_geometries.append({
                    'geometry': final_geometry,
                    'properties': {'id': building_id}
                })

        if all_combined_geometries:
            final_output_gdf = gpd.GeoDataFrame(all_combined_geometries, crs="EPSG:4326")
            final_output_gdf.to_file(output_geojson_path, driver='GeoJSON')
            print(f"結合された日影データがGeoJSON形式で保存されました: {output_geojson_path}")
        else:
            empty_gdf = gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")
            empty_gdf.to_file(output_geojson_path, driver='GeoJSON')
            print(f"有効な日影ジオメトリが生成されなかったため、'{output_geojson_path}'は空のGeoJSONとして作成されました。")

    except Exception as e:
        print(f"日影データの結合中に致命的なエラーが発生しました: {e}")
        import traceback
        traceback.print_exc()