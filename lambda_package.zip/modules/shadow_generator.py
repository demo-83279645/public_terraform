# shadow_generator.py
import geopandas as gpd
from shapely.geometry import Polygon, MultiPolygon
from shapely.ops import unary_union
import math
import pandas as pd
import json

from astropy.time import Time
from modules.solar_altitude import get_solar_altitude
from modules.solar_azimuth import get_solar_azimuth

# shadow_configは不要になったため削除
# from shadow_config import obs_time as config_obs_time

def calculate_shadows_and_footprints(geojson_filepath, shadows_output_filename=None, footprints_output_filename=None, obs_time=None):
    """
    GeoJSONファイルから建物データを読み込み、指定された時刻の太陽位置に基づいて日陰を計算し、
    結果を「日陰」と「建物の底面」のGeoJSONファイルとして保存します。
    """
    try:
        buildings_gdf = gpd.read_file(geojson_filepath)
        if buildings_gdf.empty:
            print(f"エラー: '{geojson_filepath}'ファイルに建物データが見つかりません。")
            return
        print(f"'{len(buildings_gdf)}'件の建物データを'{geojson_filepath}'から読み込みました。")
    except Exception as e:
        print(f"エラー: '{geojson_filepath}'の読み込み中にエラーが発生しました: {e}")
        return

    original_crs = buildings_gdf.crs
    if original_crs is None:
        print("警告: GeoJSONファイルにCRS情報が見つかりません。EPSG:4326（緯度経度）と仮定して処理を続行します。")
        buildings_gdf.set_crs("EPSG:4326", inplace=True, allow_override=True)
        original_crs = buildings_gdf.crs

    target_crs_epsg = 32652 # 福岡のUTMゾーン52N (メートル単位)
    try:
        buildings_gdf_proj = buildings_gdf.to_crs(epsg=target_crs_epsg)
    except Exception as e:
        print(f"エラー: CRS変換中にエラーが発生しました。EPSG:{target_crs_epsg}が適切か確認してください: {e}")
        return

    # 全建物の緯度、経度、高度の平均値を計算し、太陽位置の計算に利用
    solar_latitude = 33.5913 # デフォルト値
    solar_longitude = 130.4017 # デフォルト値
    solar_altitude_for_sun_calc = 10.0 # デフォルト値

    if not buildings_gdf.empty and 'geometry' in buildings_gdf.columns and buildings_gdf['geometry'].notna().any():
        valid_geometries = buildings_gdf[buildings_gdf['geometry'].notna()]['geometry']
        if not valid_geometries.empty:
            # ジオメトリの重心から平均緯度経度を計算（EPSG:4326に戻して計算）
            temp_gdf = buildings_gdf_proj.to_crs(epsg=4326)
            mean_lon = temp_gdf.geometry.apply(lambda g: g.centroid.x if g and not g.is_empty else None).mean()
            mean_lat = temp_gdf.geometry.apply(lambda g: g.centroid.y if g and not g.is_empty else None).mean()
            
            all_altitudes = []
            for geom in buildings_gdf.geometry:
                if geom and not geom.is_empty:
                    polygons_to_check = geom.geoms if isinstance(geom, MultiPolygon) else [geom]
                    for poly in polygons_to_check:
                        if poly and not poly.is_empty and len(poly.exterior.coords) > 0 and len(poly.exterior.coords[0]) == 3:
                            for coord in poly.exterior.coords:
                                if len(coord) == 3:
                                    all_altitudes.append(coord[2])
            
            mean_altitude = sum(all_altitudes) / len(all_altitudes) if all_altitudes else 0.0
            
            if not pd.isna(mean_lat) and not pd.isna(mean_lon):
                solar_latitude = mean_lat
                solar_longitude = mean_lon
                solar_altitude_for_sun_calc = mean_altitude 
            else:
                print("警告: 有効な建物ジオメトリから中心座標を計算できませんでした。デフォルトの太陽位置を使用します。")
        else:
            print("警告: 読み込んだGeoJSONファイルに有効なジオメトリを持つ建物がありません。デフォルトの太陽位置を使用します。")
    else:
        print("警告: 読み込んだGeoJSONファイルに建物データがないか、ジオメトリがありません。デフォルトの太陽位置を使用します。")

    print(f"\n太陽位置計算の地点: 緯度={solar_latitude:.4f}, 経度={solar_longitude:.4f}, 高度={solar_altitude_for_sun_calc:.2f}m")

    try:
        current_solar_altitude = get_solar_altitude(solar_latitude, solar_longitude, solar_altitude_for_sun_calc, obs_time)
        current_solar_azimuth = get_solar_azimuth(solar_latitude, solar_longitude, solar_altitude_for_sun_calc, obs_time)
        print(f"算出された太陽高度: {math.degrees(current_solar_altitude):.2f} 度")
        print(f"算出された太陽方位角: {math.degrees(current_solar_azimuth):.2f} 度")
    except Exception as e:
        print(f"エラー: 太陽高度または太陽方位角の計算中にエラーが発生しました: {e}")
        # 太陽計算エラー時も空のGeoDataFrameを作成し、出力
        empty_gdf = gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")
        if shadows_output_filename:
            empty_gdf.to_file(shadows_output_filename, driver='GeoJSON')
        if footprints_output_filename:
            empty_gdf.to_file(footprints_output_filename, driver='GeoJSON')
        return

    # 日陰とフットプリントの生成を分離
    if shadows_output_filename:
        generate_shadows(buildings_gdf_proj, current_solar_altitude, current_solar_azimuth, shadows_output_filename)

    if footprints_output_filename:
        generate_footprints(buildings_gdf_proj, footprints_output_filename)


def generate_shadows(buildings_gdf_proj, current_solar_altitude, current_solar_azimuth, output_filename):
    """日陰データを生成しGeoJSONファイルに保存する"""
    individual_shadow_features = []
    
    if current_solar_altitude <= 0:
        print("警告: 太陽高度が0以下であるため、日陰は生成されません。")
    else:
        shadow_azimuth_rad = current_solar_azimuth + math.pi # 太陽の逆方向

        for building_idx, (index, row) in enumerate(buildings_gdf_proj.iterrows()):
            building_id_for_output = f"building_{building_idx + 1}"
            
            height = None
            if 'measuredHeight' in row and row['measuredHeight'] is not None:
                try:
                    height = float(row['measuredHeight'])
                except (ValueError, TypeError):
                    continue

            if height is None or height <= 0:
                continue

            shadow_length = height / math.tan(current_solar_altitude)
            building_geometry = row['geometry']
            if not building_geometry or building_geometry.is_empty:
                continue

            polygons_to_process = building_geometry.geoms if isinstance(building_geometry, MultiPolygon) else [building_geometry]
            current_building_shadow_parts = []

            for poly in polygons_to_process:
                if not poly.is_empty and poly.is_valid:
                    exterior_coords_2d = [(p[0], p[1]) for p in poly.exterior.coords]
                    shadow_coords = []
                    for x, y in exterior_coords_2d:
                        dx = shadow_length * math.sin(shadow_azimuth_rad)
                        dy = shadow_length * math.cos(shadow_azimuth_rad)
                        shadow_coords.append((x + dx, y + dy))
                    
                    if len(shadow_coords) >= 3:
                        shadow_polygon_2d = Polygon(shadow_coords)
                        if not shadow_polygon_2d.is_empty and shadow_polygon_2d.is_valid:
                            current_building_shadow_parts.append(shadow_polygon_2d)

            if current_building_shadow_parts:
                unified_shadow_geom = unary_union(current_building_shadow_parts)
                if unified_shadow_geom and not unified_shadow_geom.is_empty and unified_shadow_geom.is_valid:
                    shadow_props = row.drop(columns=['geometry'], errors='ignore').to_dict()
                    shadow_props['id'] = building_id_for_output
                    individual_shadow_features.append({
                        'geometry': unified_shadow_geom,
                        'properties': shadow_props
                    })

    if individual_shadow_features:
        shadow_gdf_final = gpd.GeoDataFrame(individual_shadow_features, crs=buildings_gdf_proj.crs)
    else:
        shadow_gdf_final = gpd.GeoDataFrame(geometry=[], crs=buildings_gdf_proj.crs)
        
    try:
        shadow_gdf_final = shadow_gdf_final.to_crs(epsg=4326)
    except Exception as e:
        print(f"エラー: 伸びる影のCRSをEPSG:4326に戻す際にエラーが発生しました: {e}")

    try:
        shadow_gdf_final.to_file(output_filename, driver='GeoJSON')
        print(f"伸びる影データをGeoJSON形式で保存しました: {output_filename}")
    except Exception as e:
        print(f"エラー: 伸びる影のGeoJSONファイルの書き出し中にエラーが発生しました: {e}")

def generate_footprints(buildings_gdf_proj, output_filename):
    """建物のフットプリントデータを生成しGeoJSONファイルに保存する"""
    individual_footprint_features = []
    
    for building_idx, (index, row) in enumerate(buildings_gdf_proj.iterrows()):
        building_id_for_output = f"building_{building_idx + 1}"
        
        building_geometry = row['geometry']
        if not building_geometry or building_geometry.is_empty:
            continue
            
        polygons_to_process = building_geometry.geoms if isinstance(building_geometry, MultiPolygon) else [building_geometry]
        current_building_footprint_parts = []
        
        for poly in polygons_to_process:
            if not poly.is_empty and poly.is_valid:
                cleaned_poly_2d = Polygon([(p[0], p[1]) for p in poly.exterior.coords])
                if not cleaned_poly_2d.is_empty and cleaned_poly_2d.is_valid:
                    current_building_footprint_parts.append(cleaned_poly_2d)
        
        if current_building_footprint_parts:
            unified_footprint_geom = unary_union(current_building_footprint_parts)
            if unified_footprint_geom and not unified_footprint_geom.is_empty and unified_footprint_geom.is_valid:
                footprint_props = row.drop(columns=['geometry'], errors='ignore').to_dict()
                footprint_props['id'] = building_id_for_output
                individual_footprint_features.append({
                    'geometry': unified_footprint_geom,
                    'properties': footprint_props
                })

    if individual_footprint_features:
        footprint_gdf_final = gpd.GeoDataFrame(individual_footprint_features, crs=buildings_gdf_proj.crs)
    else:
        footprint_gdf_final = gpd.GeoDataFrame(geometry=[], crs=buildings_gdf_proj.crs)
        
    try:
        footprint_gdf_final = footprint_gdf_final.to_crs(epsg=4326)
    except Exception as e:
        print(f"エラー: 建物のフットプリントのCRSをEPSG:4326に戻す際にエラーが発生しました: {e}")

    try:
        footprint_gdf_final.to_file(output_filename, driver='GeoJSON')
        print(f"建物のフットプリントデータをGeoJSON形式で保存しました: {output_filename}")
    except Exception as e:
        print(f"エラー: 建物のフットプリントのGeoJSONファイルの書き出し中にエラーが発生しました: {e}")