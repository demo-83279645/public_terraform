# solar_azimuth.py

from astropy.coordinates import EarthLocation, AltAz, get_sun
from astropy.time import Time
from astropy import units as u
import math
import datetime
import pytz

try:
    from shadow_config import obs_time as config_obs_time
except ImportError:
    config_obs_time = None

def get_solar_azimuth(latitude, longitude, altitude, obs_time=None):
    use_time = obs_time if obs_time else config_obs_time
    location = EarthLocation(lat=latitude*u.deg, lon=longitude*u.deg, height=altitude*u.m)
    
    if not use_time:
        # タイムゾーン情報を持つ現在時刻を使用
        now = Time(datetime.datetime.now(tz=pytz.timezone('Asia/Tokyo')))
    else:
        # ISOフォーマット文字列にタイムゾーン情報が含まれるため、
        # fromisoformat()でそのままdatetimeオブジェクトに変換
        dt_obj = datetime.datetime.fromisoformat(use_time)
        now = Time(dt_obj)

    altaz_frame = AltAz(obstime=now, location=location)
    sun_position = get_sun(now).transform_to(altaz_frame)
    return sun_position.az.radian

if __name__ == "__main__":

    test_latitude = 33.5913
    test_longitude = 130.4017
    test_altitude = 10.0
    # テスト用の時刻を指定
    test_time = datetime.datetime(2025, 8, 29, 6, 0, 0).isoformat()
    azimuth_rad = get_solar_azimuth(test_latitude, test_longitude, test_altitude, test_time)
    print(f"太陽方位角: {azimuth_rad * 180 / math.pi:.2f} 度")