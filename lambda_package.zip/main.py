# main.py (S3対応版)

import datetime
import os
import json
import boto3
# ここからデバッグコードを挿入
import sys
try:
    print(f"--- [DEBUG] sys.path ({len(sys.path)} paths) ---")
    for p in sys.path:
        print(f"PATH: {p}")
    
    # ------------------------------------------------
    # 最初の import geopandas を試行する代わりに、
    # 依存ライブラリを個別に、かつネイティブに近い順でインポート
    # ------------------------------------------------
    import shapely
    print(f"✅ shapely found at: {shapely.__file__}")
    
    import fiona
    print(f"✅ fiona found at: {fiona.__file__}")

    import pyproj
    print(f"✅ pyproj found at: {pyproj.__file__}")
    
    # 全ての依存が通れば geopandas をインポート
    import geopandas
    print(f"✅ geopandas found at: {geopandas.__file__}")
    
except ImportError as e:
    # どのモジュールで失敗したかを明確にする
    print(f"❌ Layer Import FAILED: {e}")
    # 実行を停止せず、元のエラーを再発生させるために例外を再送出 (オプション)
    raise
# ここまでデバッグコードを挿入

import geopandas as gpd
from botocore.exceptions import ClientError

# modules内のカスタムモジュールをインポート
from modules.suntime_util import get_rounded_sun_times
from modules.shadow_generator import calculate_shadows_and_footprints
from modules.shadow_combiner import combine_shadow_and_footprint_geometries
from modules.preprocess_shadows import preprocess_shadow_data

s3_client = boto3.client('s3')

# ----------------------------------------------------------------------
# S3ヘルパー関数
# ----------------------------------------------------------------------
def download_file_from_s3(bucket, key, local_path):
    """S3からファイルをダウンロードする"""
    print(f"S3からダウンロード: s3://{bucket}/{key} -> {local_path}")
    try:
        s3_client.download_file(bucket, key, local_path)
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            raise FileNotFoundError(f"S3ファイルが見つかりません: s3://{bucket}/{key}")
        else:
            raise

def upload_file_to_s3(bucket, key, local_path):
    """S3にファイルをアップロードする"""
    print(f"S3にアップロード: {local_path} -> s3://{bucket}/{key}")
    s3_client.upload_file(local_path, bucket, key)

# ----------------------------------------------------------------------
# Lambdaハンドラ
# ----------------------------------------------------------------------
def main(event, context):
    """
    Step Functionsから呼び出されるLambdaハンドラ。
    Step Functionsの入力: {"date": "YYYY-MM-DD", "input_key": "geojson/input.geojson"}
    """
    
    # 環境変数からバケット名を取得 (lambda.tfで設定済み)
    INPUT_BUCKET = os.environ.get('INPUT_BUCKET')
    OUTPUT_BUCKET = os.environ.get('OUTPUT_BUCKET')
    
    # Step Functionsの入力から処理に必要なパラメータを取得
    # SFNから "input_key" (例: "geojson/chuo-ku_geojson_formatting.geojson") を渡すことを想定
    input_key = event.get('input_key')
    
    # SFNから処理日を渡すことを想定 (例: "2025-09-21")
    date_str = event.get('date', datetime.date.today().isoformat()) 
    today = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()

    # Lambdaの書き込み可能一時ディレクトリ
    TMP_DIR = '/tmp'
    
    # S3のプレフィックス (ローカルフォルダ shadow_data/temp_shadow_data に相当)
    FINAL_SHADOW_PREFIX = "final_shadow_data/"
    
    # --- 1. S3から入力ファイルを /tmp にダウンロード ---
    local_input_file = os.path.join(TMP_DIR, 'input.geojson')
    try:
        download_file_from_s3(INPUT_BUCKET, input_key, local_input_file)
    except FileNotFoundError as e:
        print(e)
        raise

    # --- 2. 処理に必要な /tmp 内のパスを定義 ---
    # ローカルの temp_shadow_dir と final_output_dir の役割を /tmp が担う
    temp_shadow_dir = os.path.join(TMP_DIR, 'temp_shadow_data')
    final_output_dir = os.path.join(TMP_DIR, 'final_shadow_data')
    
    # /tmp 内に作業ディレクトリを作成
    os.makedirs(temp_shadow_dir, exist_ok=True)
    os.makedirs(final_output_dir, exist_ok=True)
    
    # 既存の一時ファイル（前回のLambda実行で残ったもの）は /tmp が揮発性のため気にする必要はないが、
    # 念のため/tmp内をクリーンアップするロジックは削除し、os.makedirs(..., exist_ok=True)で十分。
    
    # 日の出と日没時刻を取得
    sunrise_time, sunset_time = get_rounded_sun_times(today)
    
    print(f"処理日: {today}")
    print(f"処理範囲: {sunrise_time.strftime('%H:%M')} から {sunset_time.strftime('%H:%M')} まで")
    
    # フットプリントのローカルファイル名を定義 (S3にはアップロードしない中間ファイル)
    footprint_output_file = os.path.join(temp_shadow_dir, f'footprints_temp.geojson')
    
    # 処理ループ
    current_time = sunrise_time
    
    while current_time <= sunset_time:
        
        print(f"\n--- {current_time.strftime('%Y-%m-%d %H:%M')} の日影データを生成中 ---")
        
        # 1時間ごとのファイル名を設定
        time_str = current_time.strftime('%Y%m%d_%H%M')
        shadow_output_file = os.path.join(temp_shadow_dir, f'shadows_{time_str}.geojson')
        
        # **結合後のファイルは最終出力ディレクトリに出力**
        combined_output_file = os.path.join(final_output_dir, f'combined_shadow_{time_str}.geojson')
        
        # 建物のフットプリントは一度だけ生成する
        if not os.path.exists(footprint_output_file):
            print("フットプリントファイルを初回生成します。")
            calculate_shadows_and_footprints(
                local_input_file, # ダウンロードしたローカルファイルを使用
                shadows_output_filename=shadow_output_file,
                footprints_output_filename=footprint_output_file,
                obs_time=current_time.isoformat()
            )
        else:
            print("既存のフットプリントファイルを使用します。")
            # 影のデータのみを生成
            calculate_shadows_and_footprints(
                local_input_file, # ダウンロードしたローカルファイルを使用
                shadows_output_filename=shadow_output_file,
                footprints_output_filename=None, # フットプリントは生成しない
                obs_time=current_time.isoformat()
            )

        # 影とフットプリントを結合
        combine_shadow_and_footprint_geometries(
            footprint_output_file,
            shadow_output_file,
            combined_output_file
        )
        
        # 各時間帯の影データ（shadows_{time_str}.geojson）を削除 (ローカルのクリーンアップ)
        if os.path.exists(shadow_output_file):
            os.unlink(shadow_output_file)
            print(f"影データ {os.path.basename(shadow_output_file)} を削除しました。")
        
        # 1時間進める
        current_time += datetime.timedelta(hours=1)
        
    # フットプリントデータ（footprints_temp.geojson）を削除 (ローカルのクリーンアップ)
    if os.path.exists(footprint_output_file):
        os.unlink(footprint_output_file)
        print(f"\nフットプリントデータ {os.path.basename(footprint_output_file)} を削除しました。")
        
    print("\nすべての時間帯の影データが生成されました。")
    
    # --- 重複する影データの統合処理を統合 ---
    print("\n--- 重複する影データの統合処理を開始します ---")
    preprocess_shadow_data(
        input_dir=final_output_dir, # /tmp/final_shadow_data
        output_dir=final_output_dir, # /tmp/final_shadow_data
        delete_original=True
    )
    print("--- 統合処理が完了しました。---")

    # --- 最終的な統合済みファイルをS3にアップロード ---
    final_output_keys = []
    print("\n--- 最終 GeoJSON ファイルを S3 にアップロードします ---")
    
    for filename in os.listdir(final_output_dir):
        if filename.startswith("merged_shadow_") and filename.endswith(".geojson"):
            filepath = os.path.join(final_output_dir, filename)
            
            # S3に保存するキー名を定義 (最終出力フォルダの構成に合わせる)
            s3_output_key = FINAL_SHADOW_PREFIX + filename.replace(".geojson", ".json")
            
            # ローカルの GeoJSON を読み込み、JSONとしてS3に書き出す（ファイル名の変更を含む）
            try:
                # 1. GeoJSONを読み込み
                with open(filepath, 'r') as f:
                    geojson_data = json.load(f)
                
                # 2. JSON文字列としてメモリ上で準備
                json_body = json.dumps(geojson_data, ensure_ascii=False, indent=2)

                # 3. S3にアップロード
                s3_client.put_object(
                    Bucket=OUTPUT_BUCKET,
                    Key=s3_output_key,
                    Body=json_body,
                    ContentType='application/json'
                )
                
                print(f"S3に保存: {s3_output_key}")
                final_output_keys.append(s3_output_key)

                # ローカルの元のGeoJSONファイルを削除 (メモリ節約のため)
                os.unlink(filepath)
                
            except Exception as e:
                print(f"S3へのアップロード中にエラーが発生しました: {e}")
                
    print("\nすべての処理が完了しました。")
    
    # Step Functionsに戻り値を返す
    return {
        'status': 'SUCCESS',
        'output_bucket': OUTPUT_BUCKET,
        'output_keys': final_output_keys
    }

# if __name__ == "__main__":
#     main() # ローカル実行用は削除またはコメントアウト